import PageBreadcrumb from "@/components/pageBreadcrumb/PageBreadcrumb";
import ProductForm from "@/components/product/product/ProductForm";
import Button from "@/components/ui/button/Button";
import { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Telemovvi | Produtos",
  description:
    "This is Next.js Form Elements page for TailAdmin - Next.js Tailwind CSS Admin Dashboard Template",
};

export default async function ProductsDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  return (
    <div>
      <PageBreadcrumb pageIcon="BsBoxSeam" pageTitle="Produtos" pageSubTitle="Gestão de Produtos" />
      <div className="flex justify-end mb-2">
        <Link href="/product/products">
          <Button type="submit" variant="outline" size="sm">Voltar</Button>
        </Link>
      </div>
      <ProductForm id={id} />
    </div>
  );
}