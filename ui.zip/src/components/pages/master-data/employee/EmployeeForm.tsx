"use client";

import { loadingAtom } from "@/jotai/global/loading.jotai";
import { api } from "@/service/api.service";
import { configApi, resolveResponse } from "@/service/config.service";
import { useAtom } from "jotai";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import EmployeeDataForm from "./EmployeeDataForm";
import EmployeeAddressForm from "./EmployeeAddressForm";
import EmployeeModulesForm from "./EmployeeModulesForm";
import { ResetEmployee, TEmployee } from "@/types/master-data/employee/employee.type";
import EmployeeHourForm from "./EmployeeHourForm";

type TProp = {
  id?: string;
};

export default function EmployeeForm({id}: TProp) {
  const [_, setIsLoading] = useAtom(loadingAtom);
  const [tabs] = useState<{key: string; title: string;}[]>([
    {key: 'data', title: 'Dados Gerais'},
    {key: 'address', title: 'Endereço'},
    {key: 'modules', title: 'Módulos'},
    {key: 'hours', title: 'Horários'},
  ]);
  const [currentTab, setCurrentTab] = useState<any>({key: 'data', title: 'Dados Gerais'});
  const router = useRouter();

  const { reset, watch } = useForm<TEmployee>({
    defaultValues: ResetEmployee
  });

  const getById = async (id: string) => {
    try {
      setIsLoading(true);
      const {data} = await api.get(`/users/employees/${id}`, configApi());
      const result = data.result.data;
      reset(result);
    } catch (error) {
      resolveResponse(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if(id != "create") {
      // getById(id!);
    };
  }, []);

  return (
    <>    
      <div className="flex items-center font-medium gap-2 rounded-lg transition px-2 py-2 text-sm border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/3 mb-3 text-gray-700 dark:text-gray-400">
        {
          tabs.map((x: any) => {
            return <button onClick={() => setCurrentTab(x)} className={`${currentTab.key == x.key ? 'bg-brand-500 text-white' : ''} px-3 py-1 rounded-md`} key={x.key}>{x.title}</button>
          })
        }
      </div>

      <div className="mb-2">
        {currentTab.key == "data" && <EmployeeDataForm id={id} />}
        {currentTab.key == "address" && <EmployeeAddressForm parentId={id} address={watch("address")} />}
        {currentTab.key == "modules" && <EmployeeModulesForm id={id} modules={watch("modules")}/>}
        {currentTab.key == "hours" && <EmployeeHourForm id={id} calendar={watch("calendar")}/>}
      </div>     
    </>
  );
}